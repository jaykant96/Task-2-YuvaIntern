# Sales Data Analysis Using Python

## Project overview
A beginner-friendly hands-on data analysis project using Python, pandas, NumPy, and Matplotlib.

## Objectives
- Load and inspect CSV data
- Check missing values and duplicates
- Prepare and validate fields
- Calculate sales, costs, profit, and profit margin
- Summarize performance by product and region
- Visualize monthly sales and product performance
- Export cleaned data and summary tables

## Project structure
```text
Sales_Data_Analysis_Project/
├── data/
│   └── sales_data.csv
├── outputs/
│   ├── monthly_sales.png
│   └── sales_by_product.png
├── sales_analysis.ipynb
├── requirements.txt
└── README.md
```

## Requirements
Python 3.10 or later is recommended. Install packages:
```bash
python -m pip install -r requirements.txt
```
On Windows, if `python` is not recognized, try:
```bash
py -m pip install -r requirements.txt
```

## Run the notebook
Open a terminal in the project folder and run:
```bash
jupyter notebook
```
Then open `sales_analysis.ipynb` and run the cells from top to bottom.

## Dataset
The CSV contains illustrative sample orders with dates, regions, products, quantity, unit price, and unit cost. It is a learning dataset and does not represent a real business.

## Main outputs
- Total sales, cost, profit, and profit margin
- Sales summaries by product and region
- Monthly sales trend chart
- Product sales comparison chart
- Cleaned data and summary CSVs (created when the notebook is run)

## GitHub upload
Create a new repository on GitHub, then upload the project files. Do not upload passwords, private customer data, or other sensitive information.
